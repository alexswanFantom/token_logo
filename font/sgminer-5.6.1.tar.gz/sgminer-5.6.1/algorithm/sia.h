#ifndef SIAH_H
#define SIAH_H

#include "miner.h"

extern void sia_regenhash(struct work *work);

#endif /* FRESHH_H */